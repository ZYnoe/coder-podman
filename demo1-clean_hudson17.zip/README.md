# Coder Ubuntu Template with VS Code Server, Claude CLI, Codex CLI, uv, and pixi

This Coder Docker workspace template keeps the requested CLI tooling while avoiding slow or fragile VS Code extension downloads during startup.

Included:

- Ubuntu 24.04
- `coder_agent`
- `code-server`
- Coder app: **VS Code Server**
- Claude CLI
- Codex CLI
- `uv` / `uvx`
- `pixi`
- Basic tools: `bash`, `curl`, `git`, `sudo`, `vim`, `wget`, `jq`, `python3`, `nodejs`, `npm`, `zip`, `unzip`, etc.

Not included:

- Claude Code VS Code extension
- OpenAI/Codex VS Code extension
- Startup-time VSIX downloads

This keeps workspace startup much more reliable. You can still install VS Code extensions manually from the VS Code Server Extensions panel after the workspace opens.

## Use

From this directory:

```bash
coder templates push
```

Then create a workspace from the template and open **VS Code Server** from the Coder workspace page.

## Notes

- Access to code-server uses `--auth none` because Coder already protects the app.
- code-server logs are written to `/tmp/code-server.log` inside the workspace container.
- The Docker image is still built by Terraform during provisioning unless you change `docker_image.main` to use a prebuilt registry image.


## Revised networking fix

This revision runs code-server on `127.0.0.1:13338` and exposes it with `socat` on an IPv6-capable `:13337` listener.
Coder may proxy workspace apps over the workspace agent network address, including IPv6, so binding only to localhost can cause:

```text
Failed to proxy request to application: connect tcp [fd7a:...]:13337: connection was refused
```

If the app still does not open, check inside the workspace:

```bash
cat /tmp/code-server.log
ss -lntp | grep 13337
```

You should see code-server listening on port `13337`.


## Revised v2 proxy fix

This version avoids relying on code-server's IPv6 bind behavior. The startup script:

1. Starts code-server on `127.0.0.1:13338`.
2. Starts `socat` on `:13337` with `ipv6only=0`.
3. Waits for `http://127.0.0.1:13337/healthz` before marking startup complete.

Debug inside the workspace:

```bash
cat /tmp/code-server.log
cat /tmp/code-server-proxy.log
ss -lntp | grep -E '13337|13338'
```
