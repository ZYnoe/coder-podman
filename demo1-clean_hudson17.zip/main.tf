terraform {
  required_providers {
    coder = {
      source  = "coder/coder"
      version = ">= 2.5.0"
    }
    docker = {
      source = "kreuzwerker/docker"
    }
  }
}

provider "coder" {}

# In your Coder container, the host Docker/Podman socket is mounted here.
provider "docker" {
  host = "unix:///var/run/docker.sock"
}

data "coder_provisioner" "me" {}
data "coder_workspace" "me" {}
data "coder_workspace_owner" "me" {}

locals {
  username = data.coder_workspace_owner.me.name
}

resource "coder_agent" "main" {
  arch = data.coder_provisioner.me.arch
  os   = "linux"

  startup_script = <<-EOT
    #!/usr/bin/env bash
    # Do not use `set -e` here: app startup should leave useful logs even if one step fails.

    echo "Coder workspace started."
    echo "User: $(whoami)"
    echo "Home: $HOME"

    mkdir -p "$HOME/project" "$HOME/.config/code-server" /tmp
    export PATH="$HOME/.local/bin:/usr/local/bin:/usr/local/pixi/bin:/usr/bin:/bin:$PATH"

    : > /tmp/code-server.log
    : > /tmp/code-server-proxy.log
    : > /tmp/code-server-startup.log

    {
      echo "PATH=$PATH"
      echo "code-server path: $(command -v code-server || true)"
      echo "socat path: $(command -v socat || true)"
      code-server --version || true
    } >> /tmp/code-server-startup.log 2>&1

    if ! command -v code-server >/dev/null 2>&1; then
      echo "ERROR: code-server is not installed or not on PATH." | tee -a /tmp/code-server-startup.log >&2
      exit 0
    fi

    if ! command -v socat >/dev/null 2>&1; then
      echo "ERROR: socat is not installed or not on PATH." | tee -a /tmp/code-server-startup.log >&2
      exit 0
    fi

    echo "Starting code-server on 127.0.0.1:13338 ..." | tee -a /tmp/code-server-startup.log
    nohup code-server \
      --auth none \
      --bind-addr 127.0.0.1:13338 \
      "$HOME/project" \
      >> /tmp/code-server.log 2>&1 &

    sleep 2

    echo "Starting proxy on [::]:13337 -> 127.0.0.1:13338 ..." | tee -a /tmp/code-server-startup.log
    nohup socat TCP6-LISTEN:13337,reuseaddr,fork,ipv6only=0 TCP4:127.0.0.1:13338 \
      >> /tmp/code-server-proxy.log 2>&1 &

    for i in $(seq 1 60); do
      if curl -fsS http://127.0.0.1:13338/healthz >/dev/null 2>&1; then
        echo "code-server backend is ready on 127.0.0.1:13338." | tee -a /tmp/code-server-startup.log
        break
      fi
      sleep 1
    done

    echo "Port status:" >> /tmp/code-server-startup.log
    ss -lntp 2>/dev/null | grep -E '13337|13338' >> /tmp/code-server-startup.log || true

    echo "Startup logs are in /tmp/code-server-startup.log, /tmp/code-server.log, /tmp/code-server-proxy.log"
  EOT

  env = {
    GIT_AUTHOR_NAME     = coalesce(data.coder_workspace_owner.me.full_name, data.coder_workspace_owner.me.name)
    GIT_AUTHOR_EMAIL    = data.coder_workspace_owner.me.email
    GIT_COMMITTER_NAME  = coalesce(data.coder_workspace_owner.me.full_name, data.coder_workspace_owner.me.name)
    GIT_COMMITTER_EMAIL = data.coder_workspace_owner.me.email
  }

  metadata {
    display_name = "CPU Usage"
    key          = "0_cpu_usage"
    script       = "coder stat cpu"
    interval     = 10
    timeout      = 1
  }

  metadata {
    display_name = "RAM Usage"
    key          = "1_ram_usage"
    script       = "coder stat mem"
    interval     = 10
    timeout      = 1
  }
}

resource "coder_app" "code_server" {
  agent_id     = coder_agent.main.id
  slug         = "code-server"
  display_name = "VS Code Server"
  url          = "http://localhost:13337/?folder=/home/${local.username}/project"
  icon         = "/icon/code.svg"
  subdomain    = false
  share        = "owner"

  healthcheck {
    url       = "http://localhost:13337/healthz"
    interval  = 5
    threshold = 6
  }
}

resource "docker_volume" "home" {
  name = "coder-${data.coder_workspace.me.id}-home"

  lifecycle {
    ignore_changes = all
  }
}

resource "docker_image" "main" {
  name = "coder-vscode-server-${data.coder_workspace.me.id}:latest"

  build {
    context = "./build"
    build_args = {
      USER = local.username
    }
  }

  triggers = {
    dir_sha1 = sha1(join("", [for f in fileset(path.module, "build/*") : filesha1(f)]))
  }
}

resource "docker_container" "workspace" {
  count = data.coder_workspace.me.start_count

  image = docker_image.main.name
  name  = "coder-${local.username}-${lower(data.coder_workspace.me.name)}"

  hostname = lower(data.coder_workspace.me.name)

  # Important for Podman/Docker-in-Coder:
  # Coder server often uses localhost, but inside the workspace container
  # localhost means the workspace itself. So we replace it.
  entrypoint = [
    "sh",
    "-c",
    replace(coder_agent.main.init_script, "/localhost|127\\.0\\.0\\.1/", "host.containers.internal")
  ]

  env = [
    "CODER_AGENT_TOKEN=${coder_agent.main.token}",
  ]

  volumes {
    container_path = "/home/${local.username}"
    volume_name    = docker_volume.home.name
    read_only      = false
  }
}
